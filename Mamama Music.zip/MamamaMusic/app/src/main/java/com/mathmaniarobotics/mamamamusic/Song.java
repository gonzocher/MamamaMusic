package com.mathmaniarobotics.mamamamusic;

public class Song {
    // Store the id of the song image
    private int imageDrawable;
    // Store the song title
    private String title;
    // Store the song artist
    private String artist;

    // Constructor that is used to create an instance of the Song object
    public Song(int mImageDrawable, String mTitle, String mArtist) {
        this.imageDrawable = mImageDrawable;
        this.title = mTitle;
        this.artist = mArtist;
    }

    public int getImageDrawable() {
        return imageDrawable;
    }

    public String getTitle() {
        return title;
    }

    public String getArtist() {
        return artist;
    }
}